package ch.epfl.tchu.game;

import java.util.ArrayList;
import java.util.List;

/**
 * Public, final and immutable class
 * Contains no constructor, but contains a static method to compute the longest trail of a given route network
 *
 * @Author Alexandre Iskandar (324406)
 * @Author Anirudhh Ramesh (329806)
 */
public final class Trail {

    private int length;
    private final List<Route> routes;
    private final Station s1;
    private final Station s2;

    private Trail(Station s1, Station s2, List<Route> routes, int length) {
        this.s1 = s1;
        this.s2 = s2;
        this.routes = routes;
        this.length = length;
    }

    private Trail(Station s1, Station s2, List<Route> routes) {
        this.s1 = s1;
        this.s2 = s2;
        this.routes = routes;

    }

    private static List<Trail> generateTrails(List<Route> routes){
        List<Trail> trailContainer = new ArrayList<>();
        for (Route route : routes){
            trailContainer.add(new Trail(route.station1(), route.station2(), List.of(route), route.length()));
            trailContainer.add(new Trail(route.station2(), route.station1(), List.of(route), route.length()));
        }

        return trailContainer;
    }

    private static Trail extendTrail(Trail trail, List<Route> routes){
        List<Route> rs = new ArrayList<>(routes);
        int length = 0;

        //Remove all routes that are already part of the trail
        rs.removeAll(trail.routes);

        List<Route> rsCopy = new ArrayList<>(rs);

        //Prevents ConcurrentModificationException
        for (Route r: rsCopy){
            boolean routeExtendsPathForward = trail.station2().equals(r.station1());

            if (!routeExtendsPathForward){
                rs.remove(r);
            }
        }

        Trail extendedTrail = new Trail(null, trail.station2(), trail.routes, length);

        for (Route r: rs){
            length += r.length();

            List<Route> extendedTrailRoutes = new ArrayList<>();
            extendedTrailRoutes.addAll(trail.routes);
            extendedTrailRoutes.add(r);

            extendedTrail = new Trail(trail.station1(), r.station2(), extendedTrailRoutes, length);
        }

        return extendedTrail;
    }

    /**
     * Receives list of all player-owned routes, returns the longest route of the player
     *
     * @param routes All the routes that are owned by the player
     * @return Returns the longest path of the network made up of the given routes. If multiple paths of max length => Returned path is not specified
     */

    public static Trail longest(List<Route> routes){
        
        List<Trail> shortTrail = new ArrayList<>();
        for(Route r : routes){
            shortTrail.add(new Trail(r.station1(), r.station2(), List.of(r)));
            shortTrail.add(new Trail(r.station2(), r.station1(), List.of(r)));
        }

        List<Trail> longerTrails = new ArrayList<>(shortTrail);

        if(routes.isEmpty()){
            return new Trail(null, null, routes);
        }else{
            while (!shortTrail.isEmpty()){
                List<Trail> timeTrail = new ArrayList<>();
                for (Trail t : shortTrail){
                    List<Route> possibleRoad = new ArrayList<>();
                    for (Route r : routes){
                        if((t.station2().equals(r.station1()) || t.station2().equals(r.station2())) && (!t.routes.contains(r))){
                            possibleRoad.add(r);
                        }
                    }
                    for(Route prolongation:possibleRoad){
                        List<Route> route = new ArrayList<>();
                        route.addAll(t.routes);
                        route.add(prolongation);
                        Trail newTrail = new Trail(t.station1(), prolongation.stationOpposite(t.station2()), route);
                        longerTrails.add(newTrail);
                        timeTrail.add(newTrail);

                    }


                }
                shortTrail = timeTrail;
            }

        }

        Trail longest = longerTrails.get(0);
        for (Trail l : longerTrails){
            if(l.length() > longest.length()){
                longest = l;
            }
        }
        return longest;
    }

    /**
     * @return returns the length of the trail
     */
    public int length() {
        int lengthHolder = length;
        for (Route w : routes) {
            lengthHolder += w.length();
        }

        return lengthHolder;
    }

    /**
     * @return Returns the first station of the path, else null (IFF) trail has length 0
     */
    public Station station1() {
        return ((length() > 0) ? s1 : null);
    }

    /**
     * @return Returns the last station of the path, else null (IFF) trail has length 0
     */
    public Station station2() {
        return ((length() > 0) ? s2 : null);
    }

    /**
     * @return Returns textual representation of the path, containing at least the name of first and last station (in order) as well as the length of the path in parenthesis
     */
    @Override
    public String toString() {

        String text = null;
        List<String> stations = new ArrayList<>();
        Station temp = null;

        for(int i = 0; i < routes.size() - 1; ++i){

            if(routes.get(i).station1().toString().equals(routes.get(i+1).station1().toString())){
                temp = routes.get(i).station1();
            }
            if(routes.get(i).station1().toString().equals(routes.get(i+1).station2().toString())){
                temp = routes.get(i).station1();
            }
            if(routes.get(i).station2().toString().equals(routes.get(i+1).station1().toString())){
                temp = routes.get(i).station2();
            }
            if(routes.get(i).station2().toString().equals(routes.get(i+1).station2().toString())){
                temp = routes.get(i).station2();
            }

            stations.add(temp.toString());
        }



        text = s1.toString() + " - " + String.join(" - ", stations) + " - " + s2.toString() + " (" + length() + ")";

        return text;
    }

}
