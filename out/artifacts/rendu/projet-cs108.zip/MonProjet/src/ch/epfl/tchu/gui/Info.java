package ch.epfl.tchu.gui;

public class Info {
}
